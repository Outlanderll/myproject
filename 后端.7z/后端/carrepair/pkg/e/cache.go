package e

const (
	AuthRedisKeyPrefix = "AuthToken_"
	MenuRedisKey       = "SystemMenuTree"
)
